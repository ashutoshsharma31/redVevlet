package com.redvelvet.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class BotUtils {

	public static JSONObject quickReplyTest(String message, ArrayList<String> options, String msgid) {
		// String[] str = { "Red", "Green", "Yellow", "Blue" };
		JSONObject startMessage = new JSONObject();
		startMessage.put("type", "quick_reply").put("content", new JSONObject().put("type", "text").put("text", message))
				.put("options", options).put("msgid", msgid);

		return startMessage;

	}

}
