package com.redvelvet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.redvelvet.session.Storage;
import com.redvelvet.util.BotUtils;
import com.redvelvet.util.ParseUtils;
import com.redvelvet.util.ValidateUserMessageUtils;
import com.redvelvet.session.SessionData;
import com.redvelvet.conf.MenuItems;
import com.redvelvet.conf.Quantity;
import com.redvelvet.conf.StatusMessages;
import com.redvelvet.dao.SizeDao;
import com.redvelvet.model.CartItem;
import com.redvelvet.model.GupshupObject;
import com.redvelvet.model.MenuItem;
import com.redvelvet.model.Size;

@WebServlet("/WorkServlet")
public class WorkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(WorkServlet.class);

	public WorkServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// Write Object for response writing
		PrintWriter writer = response.getWriter();

		GupshupObject go = ParseUtils.parseRequestToGupsupObject(request);
		String orderStatus = StatusMessages.START;
		String itemStatus = StatusMessages.START;

		SessionData sessionData = Storage.getObject(go.getChannelId());
		// Set Session Object or Update
		if (sessionData != null) {
			orderStatus = sessionData.getOrderStatus();
			itemStatus = sessionData.getItemStatus();
		} else {
			sessionData = new SessionData();
			sessionData.setOrderStatus(orderStatus);
			sessionData.setItemStatus(itemStatus);
			Storage.addElementToMap(go.getChannelId(), sessionData);
		}

		String usermessage = go.getUserMessage();
		ArrayList<String> options = new ArrayList<String>();
		// Parse Messages
		// For the start of converstation
		if (ValidateUserMessageUtils.getEvent(usermessage).equals("START")) {
			String message = "What would you like to order ?";
			options = MenuItems.getStartOptions();
			String msgid = "StartMessage";
			sessionData.setOrderStatus(StatusMessages.ORDER_START);
			sessionData.setItemStatus(StatusMessages.ITEM_START);
			writer.println(BotUtils.quickReplyTest(message, options, msgid));

		}
		// For quantity of the product
		else if ((sessionData.getItemStatus().equals(StatusMessages.ITEM_QUANTITY)
				|| sessionData.getItemStatus().equals(StatusMessages.ITEM_SIZE))
				&& ParseUtils.isInteger(usermessage.trim())) {
			CartItem item = sessionData.getCartItem();
			if (MenuItems.isSizeable(item.getMenuItem())) {
				SizeDao sizeDao = new SizeDao();
				if (sessionData.getItemStatus().equals(StatusMessages.ITEM_QUANTITY)) {
					sessionData.setRemQuantity(Integer.parseInt(usermessage.trim()));
				} else {
					sessionData.setRemQuantity(sessionData.getRemQuantity() - Integer.parseInt(usermessage.trim()));
				}

				if (Integer.parseInt(usermessage.toLowerCase().trim()) == 1) {
					String msgid = "SIZE_SELECT_ONE_QTY";
					String message = "What size do you want that? ";
					options = sizeDao.getAllSizesForItem(item.getMenuItem());
					sessionData.setItemStatus(StatusMessages.ITEM_SINGLE_SIZE);
					sessionData.setOrderStatus(StatusMessages.ORDER_IN_PROGRESS);
					writer.println(BotUtils.quickReplyTest(message, options, msgid));
				} else {

					ArrayList<Size> sizeList = sessionData.getSizesList();
					int sizeCounter = sessionData.getSizeCounter();

					int remQty = sessionData.getRemQuantity();
					if (sizeList.isEmpty()) {
						sizeList = sizeDao.getAllSizes(item.getMenuItem());
						sessionData.setSizesList(sizeList);
						remQty = Integer.parseInt(usermessage);
					}
					if (sizeCounter < sizeList.size()) {
						Size size = sizeList.get(sizeCounter);
						String msgid = "SIZE_SELECT_MULTIPLE";
						String message = "How many " + size.getDesc() + " ? ";
						options = Quantity.getQuantityFromZero(sessionData.getRemQuantity());
						System.out.println(" LOGS :: options " + options + " COUNTER " + sizeCounter);
						sessionData.setSizeCounter(sizeCounter + 1);
						sessionData.setItemStatus(StatusMessages.ITEM_SIZE);
						sessionData.setOrderStatus(StatusMessages.ORDER_IN_PROGRESS);
						writer.println(BotUtils.quickReplyTest(message, options, msgid));
					} else {
						String message = "Item added ..  Whats else ?";
						String msgid = "ITEM_COMPLETED";
						options = MenuItems.getReviewOrder();
						sessionData.setItemStatus(StatusMessages.ITEM_COMPLETE);
						sessionData.setOrderStatus(StatusMessages.ORDER_IN_PROGRESS);
						writer.println(BotUtils.quickReplyTest(message, options, msgid));
					}
				}
			} else {

				item.setQuantity(Integer.parseInt(usermessage.trim()));
				String message = "Item added " + item.getMenuItem().getName() + " with quantity " + item.getQuantity()
						+ "/n Whats else ?";
				String msgid = "itemaddednosize";
				options = MenuItems.getReviewOrder();
				sessionData.addItemToCart(item);
				sessionData.setItemStatus(StatusMessages.ITEM_COMPLETE);
				sessionData.setOrderStatus(StatusMessages.ORDER_IN_PROGRESS);
				writer.println(BotUtils.quickReplyTest(message, options, msgid));
			}

		}

		// If the message received is a product or menu item
		else if (MenuItems.hasItem(usermessage)) {
			MenuItem menuItem = new MenuItem();
			menuItem = MenuItems.getMenuItems(usermessage);
			sessionData.setItemStatus(StatusMessages.ITEM_IN_PROGRESS);
			sessionData.setOrderStatus(StatusMessages.ORDER_IN_PROGRESS);
			String msgid = "SetQuantity";
			if (MenuItems.checkMenuItemToOrder(menuItem)) {
				options = Quantity.getQuantity();
				String message = "Please specify quantity of " + usermessage;
				sessionData.setItemStatus(StatusMessages.ITEM_QUANTITY);
				sessionData.setCartItem(new CartItem(menuItem));
				writer.println(BotUtils.quickReplyTest(message, options, msgid));

			} else {
				// This is a parent menu
				// Will send the child product as response
				options = MenuItems.getNextOptions(menuItem);
				String message = "Which " + usermessage + " you like to order ?";
				msgid = "ParentProduct";
				writer.println(BotUtils.quickReplyTest(message, options, msgid));
			}

		}

		writer.flush();
		writer.close();

	}

}
